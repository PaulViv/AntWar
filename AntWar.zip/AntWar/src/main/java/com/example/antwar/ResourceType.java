package com.example.antwar;

public class ResourceType {

}
