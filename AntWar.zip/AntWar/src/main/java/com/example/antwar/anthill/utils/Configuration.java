package com.example.antwar.anthill.utils;

public class Configuration {

    //Configuration de l'application
    /**
     * Hauteur de l'app
     */
    public static final int HEIGHT = 600;
    /**
     * Largeur de l'appication
     */
    public static final int WIDTH = 800;

    //Configuration de la carte
    /**
     * Nombre de spots de nourritures cachés
     */
    public static final int FOOD_SPOTS = 15;
    /**
     * Densité de l'herbe
     */
    public static final int SCENERY_DENSITY = 5000;
    /**
     * Nourriture de départ des fourmillières
     */
    public static final int STARTING_FOOD_STOCK = 4000;

    //Configuration des fourmis
    /**
     * Maximum d'ouvrière sur la map
     */
    public static final int MAX_PEONS_COUNT = 2500;
    /**
     * Maximum de soldat sur la carte
     */
    public static final int MAX_SOLDIERS_COUNT = 30;
    /**
     * Maximum de points de vie des prédateurs
     */
    public static final int PREDATOR_LIFE = 70;
    /**
     * Maximum de vie de la reine
     */
    public static final int QUEEN_LIFE = 500;
    /**
     * Maximum de vie des soldats
     */
    public static final int SOLDIERS_LIFE = 50;

    private Configuration() {

    }
}
