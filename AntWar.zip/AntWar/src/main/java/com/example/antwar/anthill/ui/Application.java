/**
 *
 */
package com.example.antwar.anthill.ui;

import javax.swing.JFrame;

import com.example.antwar.anthill.controllers.Creeps;

/**
 * @author Paul
 *
 */
public class Application extends JFrame {

    private static final long serialVersionUID = 6424756108494662748L;

    public Application() {
        this.add(new GraphicEngine());
        this.setResizable(false);
        this.pack();
        this.setTitle("Ant War");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        Creeps._getInstance()._initQueensAndPredators();
    }
}
