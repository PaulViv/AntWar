package com.example.antwar;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

import java.io.IOException;

public class Main extends Application {
    @Override
    public void start(Stage window) throws IOException {
        Map map = new Map();

    }

    public static void main(String[] args) {
        launch();
    }
}