package com.example.antwar.anthill.interfaces;

import java.awt.Point;
import java.util.Vector;

public interface ObjectWithRange {
    /**
     * Générer une portée pour un objet donnée.
     *
     * @param position Position de l'objet.
     * @param width    Largeur de l'objet.
     * @param height   hauteur de l'objet.
     * @return Tableau à deux dimensions pour représenter la portée,
     *      Exemple :</br>
     *         |00(x1)|01(y1)|</br>
     *         |10(x2)|11(y2)|
     */
    public default Vector<Vector<Double>> _computeRange(final Point position, final int width, final int height) {
        final Vector<Vector<Double>> matrix = new Vector<>();
        matrix.add(new Vector<Double>());
        matrix.add(new Vector<Double>());
        matrix.get(0).add((position.x - (width / 2d)) - 10d);
        matrix.get(0).add((position.y - (height / 2d)) - 10d);
        matrix.get(1).add((position.x + (width / 2d)) + 10d);
        matrix.get(1).add((position.y + (height / 2d)) + 10d);
        return matrix;
    }
    public Vector<Vector<Double>> _getRange();
}