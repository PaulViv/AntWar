package com.example.antwar.anthill.controllers;

import com.example.antwar.anthill.threads.RunnableHolder;
import com.example.antwar.anthill.utils.Configuration;

import java.awt.Image;
import java.awt.Point;

import javax.swing.ImageIcon;

/**
 * @author paul
 *
 */
public class Anthills {

    private static class SingletonHolder {
        private static final Anthills INSTANCE = new Anthills();
    }

    public static Anthills _getInstance() {
        return SingletonHolder.INSTANCE;
    }

    private final int height;
    private final Point position;
    private RunnableHolder queen;
    private final ImageIcon sprite;
    private final int width;

    private Anthills() {
        this.width = Configuration.WIDTH / 10;
        this.height = Configuration.HEIGHT / 10;
        this.sprite = new ImageIcon("src/main/java/com/example/antwar/anthill/ui/img/Ant_hill.png");
        this.position = new Point(Configuration.WIDTH / 2, Configuration.HEIGHT / 2);
    }

    public int _getHeight() {
        return this.height;
    }

    public Point _getPosition() {
        return this.position;
    }

    public RunnableHolder _getQueen() {
        return this.queen;
    }

    public int _getWidth() {
        return this.width;
    }

    public void _setQueen(final RunnableHolder queen) {
        this.queen = queen;
    }

    public Image getSprite() {
        return this.sprite.getImage();
    }

    private Object readResolve() {
        return SingletonHolder.INSTANCE;
    }
}
