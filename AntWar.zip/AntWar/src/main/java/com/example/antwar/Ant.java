package com.example.antwar;

import java.util.ArrayList;

public class Ant {
    boolean isInjured = false;
    AntHillColor color;

    public Ant(AntHillColor Color) {

    }

    public ArrayList<Resource> kill() {
        return null;
    }

    void setInjured() {
        isInjured = true;
    }
}
