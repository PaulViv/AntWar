package main;

import com.example.antwar.anthill.ui.Application;

import java.awt.EventQueue;

public class Main {

    public static void main(final String[] args) {

        EventQueue.invokeLater(() -> {
            final Application app = new Application();
            app.setVisible(true);
        });
    }
}
