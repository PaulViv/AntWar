package com.example.antwar;

import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class Map {
    Tile[][] tiles;
    AntHill[] anthills;
    pheromoneManager pheromoneManager;

    public Map() {

    }

    public Tile getTile(Ant Ant) {
        return null;
    }

    public Tile getTile(AntHill Ant) {
        return null;
    }

    public void moveTo(Ant Ant, Tile Tile) {

    }

    public Tile getTopTile(Ant Ant) {
        return null;
    }

    public Tile getLeftTile(Ant Ant) {
        return null;
    }

    public Tile getRight(Ant Ant) {
        return null;
    }

    public Tile getBotton(Ant Ant) {
        return null;
    }
}
