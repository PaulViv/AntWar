package com.example.antwar;

public class Resource {
    public ResourceType Type;

    public Resource() {

    }
}
