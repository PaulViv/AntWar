package com.example.antwar.anthill.monitors;

import com.example.antwar.anthill.ants.AbsCreep;

/**
 * @author paul
 *
 */
public class FoodMonitor {

    private boolean foodIsAccessible = true;
    private int foodStock;
    private final AbsCreep[] foodWaitingLine;

    private int headFood;
    private int size;
    private int tailFood;

    /**
     * @param foodStock Quantité pour initialiser le stock de nourriture de la fourmillière.
     * @param capacity  Capacité maximum en nourriture de la fourmillière.
     */
    public FoodMonitor(final int foodStock, final int capacity) {
        this.foodStock = foodStock;
        this.foodWaitingLine = new AbsCreep[capacity];
        this.headFood = 0;
        this.tailFood = 0;
        this.size = 0;
    }

    /**
     * Méthode pour accéder chacun son tour au spot de nourriture
     *
     * @param value      Quantité de nourriture récupérer par la fourmi.
     * @param ant        La fourmi qui va récupérer la nourriture
     * @param isDeposing Si la fourmi veut déposer la nourriture plutôt que la prendre (la déposer à la fourmilière).
     * @return La quantité de nourriture "consommé" par la fourmi
     * @throws InterruptedException Juste au cas où
     */
    public synchronized int _accesFood(final int value, final AbsCreep ant, final boolean isDeposing)
            throws InterruptedException {
        while (!this.foodIsAccessible || !this.isFoodPrioritary(ant)) {
            if (this.isInWaitingFoodLine(ant)) {
                this.wait();
            } else {
                this.foodWaitingLine[this.headFood] = ant;
                this.headFood = (this.headFood + 1) % this.foodWaitingLine.length;
                this.size++;
                this.wait();
            }
        }
        this.foodIsAccessible = false;
        if (this.foodWaitingLine[this.tailFood] != null) {
            this.foodWaitingLine[this.tailFood] = null;
            this.tailFood = (this.tailFood + 1) % this.foodWaitingLine.length;
            this.size--;
        }
        int quantity = 0;
        if (isDeposing) {
            this.foodStock += value;
        } else {
            if (this.foodStock - value > -1) {
                this.foodStock -= value;
                quantity = value;
            }
        }
        return quantity;
    }

    public int _getFoodStock() {
        return this.foodStock < 1 ? 0 : this.foodStock;
    }

    public int _getSize() {
        return this.size;
    }

    public synchronized void _interactionDone() {
        this.foodIsAccessible = true;
        this.notifyAll();
    }

    private boolean isFoodPrioritary(final AbsCreep ant) {
        boolean result = false;
        if (this.foodWaitingLine[this.tailFood] == null || this.foodWaitingLine[this.tailFood] == ant) {
            result = true;
        }
        return result;
    }

    private boolean isInWaitingFoodLine(final AbsCreep ant) {
        boolean result = false;
        for (final AbsCreep waitingAnt : this.foodWaitingLine) {
            if (waitingAnt != null && waitingAnt == ant) {
                result = true;
            }
        }
        return result;
    }
}