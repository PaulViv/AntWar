package com.example.antwar;

import javafx.scene.layout.HBox;
import javafx.scene.shape.Polygon;
import javafx.stage.Stage;
import javafx.scene.paint.Color;

public class AntHill {
    public HBox drawAntHill(Stage stage) {
        // Create the Triangle
        Polygon triangle = new Polygon();
        triangle.getPoints().addAll(50.0, 0.0,  0.0, 50.0,100.0, 50.0);
        triangle.setFill(Color.WHITE);
        triangle.setStroke(Color.RED);

        // Create the HBox
        HBox root = new HBox();
        // Add the Children to the HBox
        root.getChildren().addAll(triangle);
        // Set Spacing of the HBox
        root.setSpacing(10);

        // Set the Style
        root.setStyle
        (
            "-fx-padding: 10;" +
            "-fx-border-style: solid inside;" +
            "-fx-border-width: 2;" +
            "-fx-border-insets: 5;" +
            "-fx-border-radius: 5;" +
            "-fx-border-color: blue;"
        );

        return root;
    }
}
