package com.example.antwar.anthill.ants;

import java.util.ArrayList;

import com.example.antwar.anthill.controllers.Anthills;

/**
 * @author paul
 *
 */
public class Peon extends AbsCreep {

    private int foodInInventory;

    public Peon(final int number, final int life, final Anthills anthill) {
        super(number, life, anthill, 2);
        this.name = "Peon " + number;
        this.foodInInventory = 0;
    }

    @Override
    protected void act() {
        if (this.life > 0) {
            this.comeBack();
        }
        if (this.life > 0) {
            this.deposit();
        }
    }

    private void comeBack() {
        this.isUnderground = false;
        this.target.x = Anthills._getInstance()._getPosition().x;
        this.target.y = Anthills._getInstance()._getPosition().y;
        try {
            this.move(true);
        } catch (final InterruptedException e) {
            e.printStackTrace();
            Thread.currentThread().interrupt();
        }
    }

    private void deposit() {
    }

    private void eat() {
    }

    private void executeChoice() {
        this.isUnderground = false;
        try {
            this.move(true);
        } catch (final InterruptedException e) {
            e.printStackTrace();
            Thread.currentThread().interrupt();
        }
    }
}
