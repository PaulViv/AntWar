module com.example.antwar {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;


    opens com.example.antwar to javafx.fxml;
//    exports com.example.antwar;
}