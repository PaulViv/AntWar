package com.example.antwar;

import java.util.ArrayList;

public class Tile {
    ArrayList<Resource> resource = new ArrayList<Resource>();
    ArrayList<Ant> Ants = new ArrayList<Ant>();
    //Ne sait pas à quoi il sert
    //Map<AntHillColor, int> pheromones = new Map<AntHillColor, int>();
    AntHill anthill;

    public Tile(AntHill AntHill) {

    }

    void addAnt(Ant Ant) {

    }

    void removeAnt(Ant Ant) {

    }

    public void dropResource(Resource Resource, Ant Ant) {

    }

    public Resource takeResource() {
        Resource resource = new Resource();

        return resource;
    }

    public int getTileRessourceQuantity() {
        return 0;
    }

    public ResourceType getRessourceType() {
        ResourceType type = new ResourceType();

        return type;
    }

    public int getPheromoneQuantity(AntHillColor color) {
        return 0;
    }

    public void addPheromone(AntHillColor color) {

    }

    public void removePheromone(AntHillColor color) {

    }
}
