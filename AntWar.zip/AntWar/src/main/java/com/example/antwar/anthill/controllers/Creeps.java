package com.example.antwar.anthill.controllers;

import com.example.antwar.anthill.ants.AbsCreep;
import com.example.antwar.anthill.ants.Queen;
import com.example.antwar.anthill.threads.RunnableHolder;
import com.example.antwar.anthill.utils.Configuration;

import java.util.ArrayList;
import java.util.List;


public class Creeps {

    private static class SingletonHolder {
        private static final Creeps INSTANCE = new Creeps();
    }

    public static Creeps _getInstance() {
        return SingletonHolder.INSTANCE;
    }

    private final ArrayList<RunnableHolder> peons = new ArrayList<>();
    private final ArrayList<RunnableHolder> predators = new ArrayList<>();
    private final ArrayList<RunnableHolder> queens = new ArrayList<>();
    private final ArrayList<RunnableHolder> soldiers = new ArrayList<>();

    private Creeps() {

    }

    public List<RunnableHolder> _getPeons() {
        return this.peons;
    }

    public List<RunnableHolder> _getPredators() {
        return this.predators;
    }

    public List<RunnableHolder> _getQueens() {
        return this.queens;
    }

    public List<RunnableHolder> _getSoldiers() {
        return this.soldiers;
    }

    public void _initQueensAndPredators() {
        final AbsCreep queen = new Queen(1, Configuration.QUEEN_LIFE, Anthills._getInstance());
        final RunnableHolder queenThread = new RunnableHolder(queen, "Queen 1");
        Anthills._getInstance()._setQueen(queenThread);
        this.queens.add(queenThread);
        queenThread.start();
    }

    private Object readResolve() {
        return SingletonHolder.INSTANCE;
    }
}
