package com.example.antwar;

public class pheromoneManager {
    void run() {

    }
}
